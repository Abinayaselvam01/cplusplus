/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

*******************************************************************************/

#include<iostream>
using namespace std;
int main()
{
    string email,location,reporttype;
    cout<<"                WEATHER APP                         \n";
    /*Name:Abinaya S
    College name:Vivekanandha College of ENgineering for Women
    datas used:Email id,Location,reporttype
    Methods used:if else statement
    */
    cout << "Enter the email id:";
    cin>>email;
    cout << "Enter the location:";
    cin>>loc;
    cout << "Do you want the weather for a day or for the week?(Enter'day'or'week'): ";
    cin>>reporttype;
    cout << "The " << reporttype <<" report for "<< loc << " is:\n";
    if (reporttype=="day") 
    {
        int date;
        cout<<"enter date:\n";
        cin>>date;
        cout << "Weather: Sunny\n";
        cout<<"TEMPERATURE:\n";
        cout << "High: 75°F\n";
        cout << "Low: 55°F\n";
    } 
    else if (reporttype=="week") 
    {
        cout << "Date:01.05.2023,sunday\n";
        cout << "Climate:cloudy\n";
        cout << "High: 75°F\n";
        cout << "Low: 55°F\n";
        cout << "\n";
        cout << "Date:02.05.2023,monday\n";
        cout << "Climate: rainy\n";
        cout << "High: 70°F\n";
        cout << "Low: 52°F\n";
        cout << "Date:03.05.2023,tuesday\n";
        cout << "Climate: sunny\n";
        cout << "High: 62°F\n";
        cout << "Low: 49°F\n";
        cout << "Date:04.05.2023,wednesday\n";
        cout << "Climate: rainy\n";
        cout << "High: 70°F\n";
        cout << "Low: 52°F\n";
        cout << "Date:05.05.2023,thursday\n";
        cout << "Climate: thunderstorm\n";
        cout << "High: 70°F\n";
        cout << "Low: 42°F\n";
        cout << "Date:06.05.2023,friday\n";
        cout << "Climate: dry\n";
        cout << "High: 70°F\n";
        cout << "Low: 52°F\n";
        cout << "Date:07.05.2023,saturday\n";
        cout << "Climate: sunny\n";
        cout << "High: 70°F\n";
        cout << "Low: 52°F\n";
    }
    else
    {
        cout << "Invalid report type entered\n";
    }

    return 0;
}